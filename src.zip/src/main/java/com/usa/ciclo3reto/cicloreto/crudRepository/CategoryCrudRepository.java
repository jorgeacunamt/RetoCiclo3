package com.usa.ciclo3reto.cicloreto.crudRepository;

import com.usa.ciclo3reto.cicloreto.model.Category;
import org.springframework.data.repository.CrudRepository;

public interface CategoryCrudRepository extends CrudRepository<Category,Integer> {

}
