package com.usa.ciclo3reto.cicloreto.crudRepository;

import com.usa.ciclo3reto.cicloreto.model.Client;
import org.springframework.data.repository.CrudRepository;

public interface ClientCrudRepository extends CrudRepository<Client,Integer> {

}
