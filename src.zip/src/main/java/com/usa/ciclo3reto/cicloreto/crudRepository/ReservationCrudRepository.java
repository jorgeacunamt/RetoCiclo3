package com.usa.ciclo3reto.cicloreto.crudRepository;

import com.usa.ciclo3reto.cicloreto.model.Reservation;
import org.springframework.data.repository.CrudRepository;

public interface ReservationCrudRepository extends CrudRepository<Reservation,Integer> {

}
