package com.usa.ciclo3reto.cicloreto.crudRepository;

import com.usa.ciclo3reto.cicloreto.model.Farm;
import org.springframework.data.repository.CrudRepository;

public interface FarmCrudRepository extends CrudRepository<Farm,Integer> {

}
