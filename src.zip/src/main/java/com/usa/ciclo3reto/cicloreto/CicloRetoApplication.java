package com.usa.ciclo3reto.cicloreto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CicloRetoApplication {

    public static void main(String[] args) {
        SpringApplication.run(CicloRetoApplication.class, args);
    }

}
