package com.usa.ciclo3reto.cicloreto.crudRepository;

import com.usa.ciclo3reto.cicloreto.model.Message;
import org.springframework.data.repository.CrudRepository;

public interface MessageCrudRepository extends CrudRepository<Message,Integer> {

}
