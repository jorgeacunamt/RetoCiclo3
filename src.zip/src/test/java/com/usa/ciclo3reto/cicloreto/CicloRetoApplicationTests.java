package com.usa.ciclo3reto.cicloreto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CicloRetoApplicationTests {

    @Test
    void contextLoads() {
    }

}
